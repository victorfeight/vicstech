module.exports = [
	[/Module not found/, /Cannot resolve/, / \.\/missingModule /, /error-handling\/index.js/]
];