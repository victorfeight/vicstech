module.exports = [
	[/Module not found/, /Cannot resolve/, / \.\/missingModule2 /, /error-handling\/index.js/]
];