module.exports = [
	[/Module not found/, /recursive-file\/a/, /abort resolving because of recursion/],
	[/Module not found/, /recursive-file\/b/, /abort resolving because of recursion/],
	[/Module not found/, /recursive-file\/c/, /abort resolving because of recursion/],
	[/Module not found/, /recursive-file\/d/, /abort resolving because of recursion/]
];