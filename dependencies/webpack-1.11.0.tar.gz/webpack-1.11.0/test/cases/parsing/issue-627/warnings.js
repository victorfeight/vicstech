module.exports = [
	[/Critical dependencies/]
];
