module.exports = function(name) {
	return require(name);
}