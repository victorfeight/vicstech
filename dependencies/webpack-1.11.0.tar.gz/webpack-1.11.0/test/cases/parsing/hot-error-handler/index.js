it("should parse a self accept with error handler", function() {
	if(module.hot) {
		module.hot.accept(function(err) {
		
		});
	}
});