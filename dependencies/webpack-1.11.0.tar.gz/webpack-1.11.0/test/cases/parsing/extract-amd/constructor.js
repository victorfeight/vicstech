module.exports = function(value) {
	this.value = value;
}