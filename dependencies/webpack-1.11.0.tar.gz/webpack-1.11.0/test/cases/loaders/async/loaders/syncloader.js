module.exports = function(content) {
	return content;
};