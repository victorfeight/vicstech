module.exports = [
	[/Module build failed: Message\nStack/]
];