module.exports = [
	[/Critical dependencies/, /b\/index\.js/]
];