module.exports = function(req) {
	return ["a", "b", "c"][req];
}