exports.beautify = {
	files: "{{lib,hot,scripts}/**/*.js,benchmark/*.js}"
};
