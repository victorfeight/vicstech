# pageA.js

``` javascript
{{pageA.js}}
```

# pageB.js

``` javascript
{{pageB.js}}
```

# pageC.js

``` javascript
{{pageC.js}}
```

# common.js

a big file...

# webpack.config.js

``` javascript
{{webpack.config.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```
