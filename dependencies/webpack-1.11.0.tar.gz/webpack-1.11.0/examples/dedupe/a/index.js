module.exports = {
	x: require("./x"),
	y: require("./y"),
	z: require("../z")
}