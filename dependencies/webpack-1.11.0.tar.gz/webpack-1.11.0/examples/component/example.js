console.log(require("a-component"));
console.log(require("b-component"));
console.log(require("c-component"));
