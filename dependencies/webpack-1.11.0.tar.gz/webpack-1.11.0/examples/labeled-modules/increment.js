require: "./math";
exports: function increment(val) {
    return add(val, 1);
};