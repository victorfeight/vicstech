var webpack = require("../../");
module.exports = {
	plugins: [
		new webpack.dependencies.LabeledModulesPlugin()
	]
}