
# example.js

``` javascript
{{example.js}}
```

# js/output.js

``` javascript
{{js/output.js}}
```

# js/1.output.js

``` javascript
{{js/1.output.js}}
```

# js/2.output.js

``` javascript
{{js/2.output.js}}
```

# js/3.output.js

``` javascript
{{js/3.output.js}}
```

# js/4.output.js

``` javascript
{{js/4.output.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```