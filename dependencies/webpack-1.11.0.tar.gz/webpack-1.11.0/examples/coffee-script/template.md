
# example.js

``` javascript
{{example.js}}
```

# cup1.coffee

``` coffee-script
{{cup1.coffee}}
```

# cup2.coffee

``` coffee-script
{{cup2.coffee}}
```

# js/output.js

``` javascript
{{js/output.js}}
```

# Info

## Uncompressed

```
{{stdout}}
```

## Minimized (uglify-js, no zip)

```
{{min:stdout}}
```