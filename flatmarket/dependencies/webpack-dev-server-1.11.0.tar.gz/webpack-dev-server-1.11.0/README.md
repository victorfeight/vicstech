# webpack-dev-server

**THIS SERVER SHOULD BE USED FOR DEVELOPMENT ONLY!**

**DO NOT USE IT IN PRODUCTION!**

It's a live reloading server for [webpack](http://webpack.github.io).

# [Documentation](http://webpack.github.io/docs/webpack-dev-server.html)

## Inspiration

This project is heavily inspired by [peerigon/nof5](https://github.com/peerigon/nof5).

## Contributing

The client scripts are built with `npm run-script prepublish`.

## License

Copyright 2012-2014 Tobias Koppers

[MIT](http://www.opensource.org/licenses/mit-license.php)
